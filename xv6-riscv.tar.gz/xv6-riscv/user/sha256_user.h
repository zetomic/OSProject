#ifndef SHA256_USER_H
#define SHA256_USER_H

void sha256_user_compute(const unsigned char *data, int len, unsigned char *output);
int sha256_syscall_compute(const unsigned char *data, int len, unsigned char *output);

#endif

