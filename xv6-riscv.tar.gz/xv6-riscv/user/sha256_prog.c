#include "kernel/types.h"
#include "user.h"
#include "sha256_user.h"

void print_hash(unsigned char *hash);

int main(int argc, char *argv[]) {
    unsigned char hash[32];
    const char *test_inputs[10] = {
        "User input 1",
        "User input 2",
        "User input 3",
        "User input 4",
        "User input 5",
        "User input 6",
        "User input 7",
        "User input 8",
        "User input 9",
        "User input 10",
    };

    for (int i = 0; i < 10; i++) {
        printf("Test Input %d: %s\n", i + 1, test_inputs[i]);

        // User-Mode SHA-256
        uint64 user_start = rdtime();
        sha256_user_compute((const unsigned char *)test_inputs[i], strlen(test_inputs[i]), hash);
        uint64 user_end = rdtime();
        printf("User-Mode Hash: ");
        print_hash(hash);
        printf("\nUser-Mode Time: %d time units\n", (int)(user_end - user_start));

        // System-Call SHA-256
        uint64 syscall_start = rdtime();
        int syscall_time = sha256_syscall_compute((const unsigned char *)test_inputs[i], strlen(test_inputs[i]), hash);
        if (syscall_time < 0) {
            printf("System-Call Hashing Failed\n");
        } else {
            printf("System-Call Hash: ");
            print_hash(hash);
            printf("\nSystem-Call Time: %d time units\n", syscall_time);
        }
        printf("\n");
    }

    exit(0);
}

void print_hash(unsigned char *hash) {
    for (int i = 0; i < 32; i++) {
        if (hash[i] < 16)
            printf("0%x", hash[i]);
        else
            printf("%x", hash[i]);
    }
}

