#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "sha256.h"

uint64 sys_sha256(void) {
    uint64 user_input, user_output, length, start_time, end_time;
    
    // Fetch arguments from user space
    if (argaddr(0, &user_input) < 0 || argaddr(1, &user_output) < 0 || argint(2, &length) < 0) {
        return -1;  // Error in arguments
    }

    char input[length + 1];
    char output[SHA256_BLOCK_SIZE * 2 + 1];  // Hex representation
    
    // Copy input from user space
    if (copyin(myproc()->pagetable, input, user_input, length) < 0) {
        return -1;  // Error copying input
    }
    input[length] = '\0';  // Null-terminate the input

    // Measure start time
    start_time = rdtime();

    // Perform SHA-256 hashing
    sha256_hash(input, output);

    // Measure end time
    end_time = rdtime();

    // Copy hash output back to user space
    if (copyout(myproc()->pagetable, user_output, output, SHA256_BLOCK_SIZE * 2 + 1) < 0) {
        return -1;  // Error copying output
    }

    // Return the elapsed time
    return end_time - start_time;
}

