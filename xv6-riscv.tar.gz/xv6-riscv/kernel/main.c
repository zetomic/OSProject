#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "defs.h"
#include "sha256.h"

volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
  if(cpuid() == 0){
    consoleinit();
    printfinit();
    printf("\n");
    printf("xv6 kernel is booting\n");
    printf("\n");
    kinit();         // physical page allocator
    kvminit();       // create kernel page table
    kvminithart();   // turn on paging
    procinit();      // process table
    trapinit();      // trap vectors
    trapinithart();  // install kernel trap vector
    plicinit();      // set up interrupt controller
    plicinithart();  // ask PLIC for device interrupts
    binit();         // buffer cache
    iinit();         // inode table
    fileinit();      // file table
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
    
    unsigned char hash[32];
    const char *test_inputs[10] = {
        "Test kernel input 1",
        "Test kernel input 2",
        "Test kernel input 3",
        "Test kernel input 4",
        "Test kernel input 5",
        "Test kernel input 6",
        "Test kernel input 7",
        "Test kernel input 8",
        "Test kernel input 9",
        "Test kernel input 10"
        
    };
    for (int i = 0; i < 10; i++) {
      // Measure start time
      uint64 start = rdtime();

      // Compute SHA-256 hash
      sha256_compute((const unsigned char *)test_inputs[i], strlen(test_inputs[i]), hash);

      // Measure end time
      uint64 end = rdtime();

      // Output results
      printf("Input: %s\n", test_inputs[i]);
      printf("Hash: ");
      for (int j = 0; j < 32; j++)
          printf("%02x", hash[j]);
      printf("\n");
      printf("Time taken: %d time units\n\n", (int)(end - start));
  }
  
  } else {
    while(started == 0)
      ;
    __sync_synchronize();
    printf("hart %d starting\n", cpuid());
    kvminithart();    // turn on paging
    trapinithart();   // install kernel trap vector
    plicinithart();   // ask PLIC for device interrupts
  }
  
  scheduler();        
}
