// sha256.h
#ifndef SHA256_H
#define SHA256_H

#include "types.h"

void sha256_compute(const unsigned char *data, unsigned int len, unsigned char *hash);

#endif // SHA256_H

